# Play CSS Space Invaders

A Pen created on CodePen.

Original URL: [https://codepen.io/jonslater204/pen/LYWQbMa](https://codepen.io/jonslater204/pen/LYWQbMa).

A reasonably complete version of Space Invaders, using only CSS,
Includes a high score table.
Works best on desktop Chromium browsers. It should detect whether the features are supported and offer you the simpler version (https://codepen.io/jonslater204/pen/PopQbrz) of the game if not.