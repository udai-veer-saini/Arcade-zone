# Daily Pen #010: A generic Infinite Runner game

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduardoLopes/pen/vYWpLQ](https://codepen.io/EduardoLopes/pen/vYWpLQ).

I made this game in less than 24 working hours, it's to celebrate 10 days making daily pens.

I used sketch.js to work with canvas.